OmotiAppTools 1.0では以下の機能があります
WebHook 送信
MessageBox 表示

まだ少ねえな
いや少なすぎだな